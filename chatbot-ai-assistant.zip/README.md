# Chatbot AI Assistant

Servidor de chatbot com integração à OpenAI.

## Rodar o projeto

```bash
npm install
npm run start
```

Certifique-se de ter um arquivo `.env` configurado com suas chaves.